from .logger import log, logger

__all__ = ["logger", "log"]
